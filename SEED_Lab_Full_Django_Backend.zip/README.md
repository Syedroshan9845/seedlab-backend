
# Samsung SEED Lab – FULL DJANGO BACKEND

## How to run
1. pip install django
2. python manage.py makemigrations
3. python manage.py migrate
4. python manage.py createsuperuser
5. python manage.py runserver

## Admin Flow
- Login at /admin
- Create users
- Assign role ADMIN or USER
- Only admin-created users can login

This is a REAL backend used by companies.
